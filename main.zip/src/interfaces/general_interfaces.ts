export interface IText_Interface {
  id: string;
}
