export const messages = {
  TOO_MANY_REQUEST: 'Too many requests from this IP. Please try again later.',
};
